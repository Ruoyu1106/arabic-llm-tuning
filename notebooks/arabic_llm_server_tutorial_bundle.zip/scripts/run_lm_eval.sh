#!/usr/bin/env bash
# 用法：bash scripts/run_lm_eval.sh <model_key> <task_set> ["EXTRA_ARGS"]
set -euo pipefail
MODEL_KEY=${1:-qwen2.5-7b-instruct}
TASK_SET=${2:-arabic-core}
EXTRA_ARGS=${3:-}

THIS_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$THIS_DIR/.." && pwd)

# 读取任务集合
TASKS=$(python - <<'PY'
import yaml, sys
cfg = yaml.safe_load(open('configs/tasks.yaml','r'))
key = sys.argv[1]
print(",".join(cfg['task_sets'][key]))
PY
"$TASK_SET")

# 读取模型参数
MODEL_ARGS=$(python - <<'PY'
import yaml, sys
cfg = yaml.safe_load(open('configs/models.yaml','r'))
key = sys.argv[1]
print(cfg['models'][key]['model_args'])
PY
"$MODEL_KEY")

OUT_DIR="results/${MODEL_KEY}"
mkdir -p "$OUT_DIR"
STAMP=$(date -u +"%Y%m%dT%H%M%SZ")
OUT_JSON="${OUT_DIR}/${MODEL_KEY}_${TASK_SET}_${STAMP}.json"

echo "[i] Tasks: $TASKS"
echo "[i] Model args: $MODEL_ARGS"

lm_eval \
  --model vllm \
  --model_args "$MODEL_ARGS" \
  --tasks "$TASKS" \
  --batch_size auto \
  --device cuda \
  --output_path "$OUT_JSON" \
  --log_samples \
  $EXTRA_ARGS

# 导出 CSV 摘要
python - <<'PY'
import json, sys, pandas as pd
j = sys.argv[1]
data = json.load(open(j))
rows=[]
for task, metrics in data.get("results", {}).items():
    flat = {k:v for k,v in metrics.items() if isinstance(v,(int,float,str))}
    flat["task"]=task
    rows.append(flat)
df=pd.DataFrame(rows)
csv=j.replace(".json",".csv")
df.to_csv(csv, index=False)
print("[✓] Wrote", csv)
PY
"$OUT_JSON"

echo "[✓] Done. Output -> $OUT_JSON"

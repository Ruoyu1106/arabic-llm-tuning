#!/usr/bin/env bash
set -euo pipefail
if command -v conda &>/dev/null; then
  eval "$(conda shell.bash hook)"
  conda create -y -n arabic-llm-eval python=3.10
  conda activate arabic-llm-eval
else
  python3 -m venv .venv
  source .venv/bin/activate
  python -m pip install -U pip
fi

pip install "torch" -U
pip install -U transformers accelerate datasets evaluate peft bitsandbytes
pip install -U vllm lm-eval pandas numpy matplotlib git-lfs "huggingface_hub[cli]"

python - <<'PY'
import torch, vllm, transformers
print("Torch:", torch.__version__, "CUDA:", torch.cuda.is_available())
print("vLLM:", vllm.__version__)
print("Transformers:", transformers.__version__)
PY
echo "[✓] Python deps ready."

import pandas as pd
import matplotlib.pyplot as plt
import glob, os, sys

# 用法：python scripts/plot_results.py results/qwen2.5-7b-instruct/*.csv
files = sys.argv[1:] or glob.glob("results/*/*.csv")
if not files:
    print("No CSV files found.")
    raise SystemExit

dfs = []
for f in files:
    try:
        df = pd.read_csv(f)
        df["source_file"] = os.path.basename(f)
        dfs.append(df)
    except Exception as e:
        print("skip", f, e)

all_df = pd.concat(dfs, ignore_index=True)
# 简单按 task + 某通用指标（如 acc）画出条形图
metric = None
for c in ["acc", "accuracy", "exact_match", "f1"]:
    if c in all_df.columns:
        metric = c; break

if metric is None:
    print("No common metric column found (tried acc/accuracy/exact_match/f1).")
    raise SystemExit

pivot = all_df.pivot_table(index="task", columns="source_file", values=metric, aggfunc="mean")
ax = pivot.plot(kind="bar", figsize=(10,6))
ax.set_ylabel(metric)
ax.set_title("Arabic LLM Evaluation Summary")
plt.tight_layout()
plt.savefig("results/summary_plot.png")
print("[✓] Saved results/summary_plot.png")

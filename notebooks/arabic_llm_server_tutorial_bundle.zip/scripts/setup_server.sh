#!/usr/bin/env bash
set -euo pipefail
sudo apt-get update
sudo apt-get install -y git git-lfs build-essential tmux htop nvtop screen wget curl python3-venv
git lfs install
echo "[✓] Base system ready."

#!/usr/bin/env bash
# 用法：bash scripts/run_vllm_server.sh <model_key> [port]
set -euo pipefail
MODEL_KEY=${1:-qwen2.5-7b-instruct}
PORT=${2:-8000}

MODEL_ARGS=$(python - <<'PY'
import yaml, sys
cfg = yaml.safe_load(open('configs/models.yaml','r'))
key = sys.argv[1]
print(cfg['models'][key]['model_args'])
PY
"$MODEL_KEY")

# 提取 pretrained 名称
PRETRAINED=$(python - <<'PY'
import sys
s=sys.argv[1]
for part in s.split(","):
    if part.startswith("pretrained="):
        print(part.split("=",1)[1]); break
PY
"$MODEL_ARGS")

echo "[i] Serving $PRETRAINED at port $PORT"
python -m vllm.entrypoints.openai.api_server \
  --model "$PRETRAINED" \
  --port "$PORT" \
  --trust-remote-code \
  --gpu-memory-utilization 0.90
